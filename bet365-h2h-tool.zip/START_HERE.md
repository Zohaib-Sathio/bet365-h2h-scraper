# bet365 head-to-head percentages — how to use it

## 1. The live page (nothing to install)

**https://bet365-h2h.onrender.com**

Pick a sport, a look-ahead window (3 hours to 10 days) and, if you want to
narrow things down, a continent, a country and a league. Type in the search box
to find a team. **Download Excel** gives you exactly what is on screen.

Every row has a **verify** link that opens bet365's own statistics page for
that fixture, so any number can be checked at the source in one click.

The page shows matches that carry bet365's statistics icon and have at least
one previous meeting between the two teams. Nothing is estimated or filled in;
if bet365 has no head-to-head record for a fixture, that fixture is left out.

## 2. What is in the spreadsheet

The four columns you asked for come first:

```
Match | Home Team Win % | Draw % | Away Team Win %
```

then the supporting detail:

```
Sport | Continent | Country | League | Date (UTC) | Kick-off (UTC) |
Home Team | Away Team | Meetings | Home Wins | Draws | Away Wins |
Source (bet365 stats page)
```

`sample-output/` holds two ready-made exports and a screenshot showing one row
checked against bet365's own page (Atlanta United vs New York Red Bulls —
21 meetings, 4 / 19%, 6 / 29%, 11 / 52%, identical on both sides).

## 3. Running it yourself (optional)

Requires Python 3.11 or newer.

```bash
pip install -r requirements.txt

# the web page, at http://localhost:8000
python -m uvicorn webapp:app --port 8000

# or straight to a file, without the web page
python run.py --hours 24
python run.py --days 7 --league "Premier League" --out premier_week
python run.py --days 7 --simple        # only the four columns
```

Files are written to `output/` as `.xlsx` and `.csv`.

## 4. Hosting it on your own account

The tool is already deployed on Render's free plan. To move it to an account
you own: push this folder to a GitHub repository, create a free Render web
service from it, and Render will read `render.yaml` automatically. A
`Dockerfile` is included if you would rather run it on your own server.

`README.md` has the technical detail — where the data comes from, which
endpoints are used and how the numbers are calculated.
